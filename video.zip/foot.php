<?php

?>

<div class="panel-body" style="text-align: center;">

 <div class="container-fluid">

  <a target="_blank" href="http://www.ldzy.cc" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-globe"></span>绿岛资源</a>

<br><span class="copyright">Copyright &copy; 2017 <a href="http://www.ldzy.cc" title="绿岛资源" target="_blank">绿岛资源</a></span>

</div>

</body>

</html>