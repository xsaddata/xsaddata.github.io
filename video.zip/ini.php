<?php

  $ini = array(

  'title'=>'绿岛资源站VIP视频解析站',//网站标题

  'keywords'=>'绿岛资源站，只为有需要我的人做的网站',//网站关键字

  'description'=>'小人物做的小网站，只是为了我的朋友们，要打我的随意',//网站描述

  'kfqq'=>'www.ldzy.cc',//客服QQ

  );

?>